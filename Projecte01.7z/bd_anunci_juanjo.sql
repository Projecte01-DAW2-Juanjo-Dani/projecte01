-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-10-2017 a las 18:31:33
-- Versión del servidor: 10.1.26-MariaDB
-- Versión de PHP: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bd_anunci_juanjo`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `anunci`
--

CREATE TABLE `anunci` (
  `anu_id` int(4) NOT NULL,
  `anu_titol` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `anu_data_anunci` date NOT NULL,
  `anu_data_robatori` date NOT NULL,
  `anu_municipi_robatori` varchar(35) COLLATE utf8_spanish_ci NOT NULL,
  `anu_provincia_robatori` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `anu_codi_postal_robatori` varchar(5) COLLATE utf8_spanish_ci NOT NULL,
  `anu_descripcio_robatori` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `anu_marca` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `anu_model` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `anu_color` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `anu_antiguitat` varchar(25) COLLATE utf8_spanish_ci DEFAULT NULL,
  `anu_descripcio` text COLLATE utf8_spanish_ci NOT NULL,
  `anu_numero_serie` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `anu_foto` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `anu_compensacio` decimal(6,2) DEFAULT NULL,
  `anu_tipusbici` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `anunci`
--

INSERT INTO `anunci` (`anu_id`, `anu_titol`, `anu_data_anunci`, `anu_data_robatori`, `anu_municipi_robatori`, `anu_provincia_robatori`, `anu_codi_postal_robatori`, `anu_descripcio_robatori`, `anu_marca`, `anu_model`, `anu_color`, `anu_antiguitat`, `anu_descripcio`, `anu_numero_serie`, `anu_foto`, `anu_compensacio`, `anu_tipusbici`) VALUES
(21, 'Conor 7200 verde', '2017-09-16', '2017-09-15', 'Bollullos de la Mitación ', 'Sevilla', '', 'Robada del garaje de mi casa.', 'Conor', '7200', 'Negra con letras verdes', '1 año', 'MTB prácticamente nueva, ruedas de 29\", peso 14Kg.\r\n\r\nNumero de serie del cuadro: Y6K00400', 'Y6K00400', 'foto1.png', '20.00', 'Mountain Bike'),
(22, 'Merida Matts tfs 100-D', '2017-10-20', '2017-08-17', 'Guadalajara', 'Guadalajara', '', 'Robada en trastero', 'Merida', 'Matts Tfs 100-D', 'Blanca, roja y negra', '2012', 'Talla 20\", ruedas 26\", con triángulo con cámara y herramientas, con punteras y cuentakilometros inalámbrico. Número de serie: F042R016016GIL111011.', 'F042R016016GIL1', 'foto1.png', NULL, 'Hibrida'),
(23, 'Mérida Doble suspensión Blanca - roja Rockshox', '2017-08-19', '2017-08-18', 'Arroyomolinos', 'Madrid', '', 'Roba en plena calle, atada a una farola delante del ayuntamiento', 'Merida', 'Big ninety nine 9 600', 'Blanca y roja', '2014', 'Merida Big Ninety 9. 600, doble amortiguación - suspensión, Blanca - roja, 29\". Pedales XT, Rockshox amortiguador y horquilla, Cuernos blancos en manillar, N/S M4FJ04648', 'M4FJ04648', 'foto1.png', '150.00', 'Mountain Bike'),
(25, 'Conor 6300', '2017-05-31', '2017-06-01', 'L\'Hopsitalet de Llobregat', 'Barcelona', '', 'Robada en el garaje de mi casa (Bellvitge)', 'Conor', '6300', 'Naranja', '2017', '27,5 pulgadas\r\nNº serie del cuadro: LF16E01942', 'LF16E01942', 'foto1.png', '50.00', 'Plegable'),
(26, 'Bicicleta de Paseo Órbita Classic Negra', '2016-08-25', '2016-08-20', 'Valladolid', 'Valladolid', '', 'Robada en Valladolid en la calle Las Mieses, 10. Estaba candada en la calle a la barandilla de acceso al garaje del bloque.', 'Orbit', 'Classic', 'Negra', '2015', 'Cuadro de paseo barra baja/alta. Tubería de acero “hi-ten”. Biela de plato único de acero forrado 46 D. Cambio trasero de 6 velocidades “Shimano TY21”. Puño rotativo 6v. Ruedas 26”. Cubiertas 26x1.3/8 dibujo liso. Frenos V-brake aluminio (manetas y puentes). Guardacadenas metálico, guardabarros, luz y transportín.', NULL, 'foto1.png', '10.00', 'Paseo'),
(27, 'CUBE AMS 125 Pro series', '2015-12-31', '2016-01-01', 'Tiana', 'Barcelona', '', 'Robada de trastero con cerradura', 'CUBE', 'AMS 125 Pro series', 'Negra', '2010', 'Bicicleta de montaña Cube AMS Pro series 125, doble suspensión, talla S, ruedas 26\".\r\nTransmisión SLX/XT 3x9. Horquilla RockShox Revelation U-Turn 120-140mm con mando remoto. Amortiguador FOX RP 23 125mm. Neumáticos Specialized Purgatory Control 2.2 / Maxxis Advantage 2.25.', '', 'foto1.png', NULL, 'Mountain Bike'),
(28, 'LAPIERRE 529 EDGE', '2017-04-01', '2017-03-05', 'Barcelona', 'Barcelona', '', 'Robada por la noche en el cuarto trastero donde estaba guardada bajo llave y 3 candados ', 'LAPIERRE', '529 EDGE', 'Negra, azul y amarilla', '2017', 'Numero FRAME : LP7411344\r\nCuadroEDGE 29’’ ALLOY SUPREME 4 DISC\r\nHorquillaSUNTOUR SF14XCR AIR RL-R-29’’ 100mm with Remote\r\nJuego de direcciónFSA NO. 10 ZS 50/44 1.6 Top Cap\r\nTeniendo inferiorSHIMANO SM-BB52\r\nBielasSHIMANO FCMT500 40x30x22 175mm\r\nPotenciaLAPIERRE EDGE AS-DC1 7° Ø: 31.8mm L: 75mm (M) / 90mm (L, XL)\r\nTija de sillínLAPIERRE EDGE SP-DC1 Ø: 31.6mm L: 350mm\r\nManillarLAPIERRE EDGE HB-FB11L W: 720mm Ø: 31.8mm\r\nCambio delanteroSHIMANO DEORE FDM610L6 34.9mm\r\nCambio traseroSHIMANO SLX RDM670SGS 10-Speed\r\nFrenosSHIMANO HYDRAULIC ALTUS BRM315- SHIMANO SMRT26 180mm / 160mm 6 Bolt Type\r\nManetas de CambioSHIMANO DEORE SLM610 3x10-Speed\r\nSillínLAPIERRE EDGE STEEL RAIL\r\nRuedas:529: LAPIERRE DOUBLE WALL 29x19C DISC - FORMULA DC20LW 32H BLACK QR9mm - FORMULA DC22LW 32H BLACK QR10mm\r\nSprocketSHIMANO DEORE CSHG50 11x36 10-Speed\r\nNeumáticos 529: MICHELIN WILD GRIP’R 29x2.25 (Front) / MICHELIN COUNTRY RACE’R 29x2.10 (Rear)\r\nTamañoM', 'LP7411344', 'foto1.png', NULL, 'Carretera'),
(29, 'LAPIERRE Sensium200', '2017-05-22', '2017-05-20', 'Jerez de la frontera', 'Cádiz', '', '', 'Lapierre', 'Sensium 200', 'Negra y blanca', '2014', 'Bicicleta de Carbono marca Lapierre en perfecto estado, robada el pasado sábado 20 de mayo de 2017, en Jerez de la Frontera (Cádiz)', NULL, 'foto1.png', '78.59', 'Mountain Bike');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `anunci`
--
ALTER TABLE `anunci`
  ADD PRIMARY KEY (`anu_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `anunci`
--
ALTER TABLE `anunci`
  MODIFY `anu_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
