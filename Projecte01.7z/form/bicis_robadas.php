<!DOCTYPE html>
<html>
<head>
	<title>Conector</title>
</head>
<body>
	<?php
		$conexion = mysqli_connect("localhost", "root", "", "bd_anunci_juanjo");
		$acentos = mysqli_query($conexion, "SET NAMES 'utf8'");
		$modelobici = $_REQUEST['modelo'];
		$colorbici = $_REQUEST['color'];
		$tipobici = $_REQUEST['tipobici'];



		$q = "SELECT * FROM anunci";
		echo "$q <br />";

		$query = mysqli_query($conexion, $q);

		if (mysqli_num_rows($query)>0) {
			while ($anunciosbicis=mysqli_fetch_array($query)) {
				echo "<div style='width: 900px; float: left; margin-right: 10px; margin-bottom: 10px; border: 2px solid black'>";
				echo "<b>Titol anunci:</b> $anunciosbicis[anu_titol]<br/>";
				echo "<img src='img/bicis/$anunciosbicis[anu_foto]'<br><br>";
				echo "<b>Data anunci:</b> $anunciosbicis[anu_data_anunci]<br/>";
				echo "<b>Data robatori:</b> $anunciosbicis[anu_data_robatori]<br/>";
				echo "<b>Ubicacio robatori:</b> $anunciosbicis[anu_ubicacio_robatori]<br />";
				echo "<b>Descripcio robatori:</b> $anunciosbicis[anu_descripcio_robatori]<br />";
				echo "<b>Marca bici:</b> $anunciosbicis[anu_marca]<br />";
				echo "<b>Model bici:</b> $anunciosbicis[anu_model]<br />";
				echo "<b>Color bici:</b> $anunciosbicis[anu_color]<br />";
				echo "<b>Antiguitat bici:</b> $anunciosbicis[anu_antiguitat]<br />";
				echo "<b>Descripcio bici:</b> $anunciosbicis[anu_descripcio]<br />";
				echo "<b>Numero serie de la bicicleta:</b> $anunciosbicis[anu_numero_serie]<br />";
				echo "<b>Compensacio per trobar la bicicleta:</b> $anunciosbicis[anu_compensacio]<br />";
				echo "<b>Tipo bicicleta:</b> <br />";
				echo "</div>";
			}
		} else {
			echo "<h1>NO HAY ANUNCIOS QUE MOSTRAR</h1>";
		}



	?>
</body>
</html>